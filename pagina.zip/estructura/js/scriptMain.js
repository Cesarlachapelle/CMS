
$(document).ready(function(){
	
	$("#footer").appendTo("#contenedorDerecho").css("padding-bottom","0px");
	
	$("body").css("background-color","#004A72");
	
});