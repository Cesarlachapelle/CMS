
$(document).ready(function(){
	$('#menu').hide();

	$('#footer').prepend("<h5>Todo Noticias &#169; Programación Web <br><br> ITLA 2015</h5>");

	$('#footer').css("background-color","#1A1919");
	$('#footer').css("color","#555555");

	$('#footer h6').hide();
});

