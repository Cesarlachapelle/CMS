

$(document).ready(function(){
	
	$("#footer").appendTo("#contenedorDerecho");
	
	$("body").css("background-color","#004A72");
	
});