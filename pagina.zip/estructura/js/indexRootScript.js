
$(document).ready(function(){
	$('#menu').hide();

	$('body').css("background-color","#171717");

	$('#footer').prepend("<h5>Todo Noticias &#169; Programación Web <br><br> ITLA 2015</h5>");

	$('#footer').css("background-color","##303030");
	$('#footer').css("color","#555555");

	$('#footer h6').hide();
});